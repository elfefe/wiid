package com.elfefe.wiid.controllers;

import android.content.Context;
import com.google.android.material.navigation.NavigationView;

public class MainNavigationView extends NavigationView {
    public MainNavigationView(Context context) {
        super(context);
    }
}
