package com.elfefe.wiid.utility

object PreferenceUtils {
    const val KEY = "coffeejoin preferences"
    const val APP_ID = "31B0B8B4-CE4E-4AFC-8F22-419B629CEC81"
}